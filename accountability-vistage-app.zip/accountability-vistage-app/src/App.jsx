export default function App() {
  return (
    <div style={{padding:"40px", fontFamily:"Arial"}}>
      <h1>Accountability Grupo 322</h1>
      <p>La app está funcionando correctamente.</p>

      <div style={{
        border:"1px solid #ccc",
        padding:"20px",
        borderRadius:"10px",
        marginTop:"20px"
      }}>
        <h2>Seguimiento rápido</h2>

        <input placeholder="Miembro"
          style={{display:"block", marginBottom:"10px", padding:"10px", width:"300px"}} />

        <input placeholder="Tema Clave"
          style={{display:"block", marginBottom:"10px", padding:"10px", width:"300px"}} />

        <input placeholder="Compromiso"
          style={{display:"block", marginBottom:"10px", padding:"10px", width:"300px"}} />

        <button style={{
          padding:"10px 20px",
          background:"black",
          color:"white",
          border:"none",
          borderRadius:"8px"
        }}>
          Guardar
        </button>
      </div>
    </div>
  )
}
